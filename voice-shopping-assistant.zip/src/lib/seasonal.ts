export const seasonal: Record<number, string[]> = {
  0:["citrus"],1:["broccoli"],2:["mango"],3:["mango"],4:["watermelon"],
  5:["cucumber"],6:["corn"],7:["grapes"],8:["apple"],9:["pumpkin"],
  10:["greens"],11:["oranges"]
}