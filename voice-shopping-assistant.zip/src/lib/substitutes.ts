export const substitutes: Record<string,string[]> = {
  milk:["almond milk","soy milk"],
  bread:["multigrain bread"]
}